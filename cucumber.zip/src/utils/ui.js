// src/utils/ui.js
const { expect } = require('@playwright/test');
const { BasePage } = require('../core/basePage');
const { getSpec } = require('./locators');
const audit = require('../../tests/support/audit');


class UI extends BasePage {
  constructor(page, attach) {
    super(page, attach);
    this._container = null;
  }

  within(containerKey) {
    this._container = containerKey;
    return this;
  }

  async _loc(key) {
    // Resolve spec + candidates for audit
    const spec = getSpec(key);
    const candidates = Array.isArray(spec.candidates)
      ? spec.candidates
      : [spec.selector].filter(Boolean);

    let locator;
    if (this._container) {
      const container = await this.byKey(this._container);
      locator = await this.byKey(key, () => container);
      this._container = null;
    } else {
      locator = await this.byKey(key);
    }

    // Best-effort: discover which selector matched (first visible/attached)
    let usedSelector = null;
    for (const sel of candidates) {
      try {
        const l = this._locator(sel);
        await l.first().waitFor({ state: 'attached', timeout: 1 });
        usedSelector = sel;
        break;
      } catch { /* keep trying */ }
    }

    audit.recordLocate({
      key,
      candidates,
      usedSelector,
      url: this.page.url(),
    });

    return locator;
  }

  async exists(key, timeout = 2000) {
    const spec = getSpec(key);
    const cands = Array.isArray(spec.candidates)
      ? spec.candidates
      : [spec.selector].filter(Boolean);

    for (const sel of cands) {
      const loc = this._locator(sel);
      try {
        await loc.first().waitFor({ state: 'visible', timeout });
        return true;
      } catch {
        try {
          await loc.first().waitFor({ state: 'attached', timeout: Math.min(600, timeout) });
          return true;
        } catch { /* try next */ }
      }
    }
    return false;
  }

  async debugCandidates(key, timeout = 1000) {
    const lines = [`Locator debug for key "${key}":`];
    try {
      const spec = getSpec(key);
      const cands = Array.isArray(spec.candidates)
        ? spec.candidates
        : [spec.selector].filter(Boolean);
      let i = 0;
      for (const sel of cands) {
        i += 1;
        const loc = this._locator(sel);
        try {
          await loc.first().waitFor({ state: 'attached', timeout });
          const count = await loc.count();
          lines.push(`- [${i}] ATTACHED (${count}) :: ${sel}`);
          try {
            await loc.first().waitFor({ state: 'visible', timeout: 200 });
            lines.push(`      ↳ VISIBLE`);
          } catch {
            lines.push(`      ↳ not visible`);
          }
        } catch {
          lines.push(`- [${i}] MISSING :: ${sel}`);
        }
      }
    } catch (e) {
      lines.push(`! getSpec/byKey failed: ${(e && e.message) || e}`);
    }
    const msg = lines.join('\n');
    try { await this.attach?.(msg); } catch {}
    return msg;
  }

  async click(key, { waitVisible = true, timeout = 10000 } = {}) {
    const loc = await this._loc(key);
    if (waitVisible) await expect(loc).toBeVisible({ timeout });

    // capture tiny DOM snippet for audit
    const h = await loc.first().elementHandle();
    const snippet = h ? await h.evaluate(el => el.outerHTML?.slice(0, 200)) : null;

    await loc.click();

    audit.recordClick({
      key,
      usedSelector: undefined, // already logged in locate
      url: this.page.url(),
      snippet,
    });
    await this.attach?.(`Clicked ${key}`);
  }

  async fill(key, value, { timeout = 10000 } = {}) {
    const loc = await this._loc(key);
    await expect(loc).toBeVisible({ timeout });

    const h = await loc.first().elementHandle();
    const snippet = h ? await h.evaluate(el => el.outerHTML?.slice(0, 200)) : null;

    await loc.fill(String(value ?? ''));
    audit.recordFill({
      key,
      usedSelector: undefined,
      url: this.page.url(),
      value,
      snippet,
    });
    await this.attach?.(`Filled ${key}`);
  }

  async selectByLabel(key, label, { timeout = 10000 } = {}) {
    const loc = await this._loc(key);
    await expect(loc).toBeVisible({ timeout });

    const h = await loc.first().elementHandle();
    const snippet = h ? await h.evaluate(el => el.outerHTML?.slice(0, 200)) : null;

    await loc.selectOption({ label: String(label) });
    audit.recordSelect({
      key,
      usedSelector: undefined,
      label,
      url: this.page.url(),
      snippet,
    });
    await this.attach?.(`Selected "${label}" in ${key}`);
  }

  async check(key, { timeout = 10000 } = {}) {
    const loc = await this._loc(key);
    await expect(loc).toBeVisible({ timeout });

    const h = await loc.first().elementHandle();
    const snippet = h ? await h.evaluate(el => el.outerHTML?.slice(0, 200)) : null;

    let changed = false;
    if (!(await loc.isChecked())) {
      await loc.check();
      changed = true;
    }
    audit.recordCheck({
      key,
      usedSelector: undefined,
      checked: changed ? 'checked' : 'already-checked',
      url: this.page.url(),
      snippet,
    });
    await this.attach?.(changed ? `Checked ${key}` : `Already checked: ${key}`);
  }

  async expectVisible(key, timeout = 10000) {
    const loc = await this._loc(key);
    await expect(loc).toBeVisible({ timeout });
    await this.attach?.(`Visible: ${key}`);
  }

  async text(key, { timeout = 10000 } = {}) {
    const loc = await this._loc(key);
    await expect(loc).toBeVisible({ timeout });
    return await loc.textContent();
  }

  // Modal save verifier + borrower tab snapshot
  async ensureModalSaved(modalKey = 'Borrowers.modal.root', { timeout = 6000 } = {}) {
    const modal = await this._loc(modalKey);
    try {
      await modal.waitFor({ state: 'detached', timeout });
      audit.recordModal({ action: 'close', key: modalKey, ok: true, url: this.page.url() });
      await this.attach?.('Modal closed (save presumed successful).');

      // snapshot borrower tabs if present
      const tabs = await this.page.locator('.nav-tabs li a, .borrowers .nav li a').allTextContents().catch(() => []);
      if (tabs && tabs.length) {
        audit.recordTabs({ names: tabs.map(s => s.trim()).filter(Boolean), url: this.page.url() });
        await this.attach?.(`Borrower tabs now: ${tabs.join(' | ')}`);
      }
      return;
    } catch {
      const msgs = this.page.locator(
        ".has-error .help-block, .ng-invalid + .help-block, .error, .validation-error, .alert-danger"
      );
      const texts = await msgs.allTextContents().catch(() => []);
      audit.recordModal({
        action: 'close',
        key: modalKey,
        ok: false,
        details: texts.join(' | ') || '<none>',
        url: this.page.url(),
      });
      await this.attach?.(
        `Modal did not close within ${timeout}ms. Visible validation: ${texts.join(' | ') || '<none>'}`
      );
      throw new Error('Modal did not close (likely validation or save failure).');
    }
  }

    async assertBorrowerTabVisible(timeout = 8000) {
    // 1) Fast path: header is present & visible
    try {
      await this.expectVisible('Borrowers.header', timeout);
      return;
    } catch (e) {
      // fall through to try to bring it into view
    }

    // 2) Try to scroll the section into view, then re-assert header
    try {
      const section = await this.byKey('Borrowers.section');
      if (section && typeof section.scrollIntoViewIfNeeded === 'function') {
        await section.scrollIntoViewIfNeeded();
      } else {
        // fallback scroll to top; harmless if already in view
        await this.page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
      }
      await this.expectVisible('Borrowers.header', Math.max(2000, Math.floor(timeout / 2)));
      return;
    } catch (e2) {
      // fall through to final throw
    }

    // 3) No luck → emit a clear error (BasePage expectVisible already attached diagnostics)
    throw new Error('Borrowers tab/section is not visible on the page');
  }
  // --- Add to the UI class ---

/** Wait until the New Contact modal is fully gone. */
async waitForBorrowerModalClose(timeout = 12000) {
  const modal = this.page.locator(".modal-content:has(.modal-title)");
  // If it’s still there, wait for it to detach
  if (await modal.count()) {
    await modal.first().waitFor({ state: 'detached', timeout }).catch(() => {});
    await this.attach?.('Modal closed (save presumed successful).');
  }
}

/** Ensure the Borrowers accordion is open and interactive. */
async ensureBorrowersOpen() {
  // click header (idempotent) and then wait for button presence
  const hdr = await this.byKey('Borrowers.header');
  await hdr.click();
  // Either "open" panel is visible OR "Add Borrower" button is interactable
  const openPanel = this.page.locator(
    "xpath=//span[contains(@class,'grid-title') and normalize-space()='Borrowers']/ancestor::*[contains(@class,'grid-accordion')][1][contains(@class,'open')]"
  );
  await Promise.race([
    openPanel.first().waitFor({ state: 'visible', timeout: 8000 }),
    (async () => { const btn = await this.byKey('Borrowers.addBorrower'); await btn.waitFor({ state: 'visible', timeout: 8000 }); })()
  ]);
  await this.attach?.('Borrowers panel is open.');
}

/** Strong assertion that the Borrowers panel is open (uses the button as oracle). */
async assertBorrowersOpen() {
  await this.expectVisible('Borrowers.header');               // header present
  const addBtn = await this.byKey('Borrowers.addBorrower');   // button present => panel open
  await addBtn.waitFor({ state: 'visible', timeout: 8000 });
  await this.attach?.('Asserted Borrowers panel open (Add Borrower visible).');
}

}

module.exports = { UI };
