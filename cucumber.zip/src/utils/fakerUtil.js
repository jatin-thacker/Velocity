/**
 * helpers/fakerUtil.js – Test data helper (Faker + curated static addresses)
 *
 * Usage:
 *   const faker = require('../utils/fakerUtil');
 *   const name = faker.getName();                      // { firstName, lastName, fullName }
 *   const addrON = faker.getAddress('ON');            // filter by province (code or full name)
 *   const addrAny = faker.getAddress();               // any province
 *   const n = faker.numberInRange('1 million', '1.5 million'); // 2 decimals by default
 *
 * Notes:
 *   - Static addresses are loaded from data/addresses.json (array of objects).
 *   - Your address records may include many fields (latitude, longitude, …).
 *     We only return these: street_no, street, str_name, str_type, str_dir, unit, city, postal_code, province
 */

const { faker: fakerLib } = require('@faker-js/faker');
const fs = require('node:fs');
const path = require('node:path');

function tryLoadAddresses() {
  try {
    const file = path.resolve(process.cwd(), 'data', 'addresses.json');
    if (fs.existsSync(file)) {
      const raw = fs.readFileSync(file, 'utf-8');
      const list = JSON.parse(raw);
      if (Array.isArray(list)) return list;
    }
  } catch (e) {
    console.warn('Could not load static addresses:', e.message);
  }
  return [];
}
const STATIC_ADDRESSES = tryLoadAddresses();

// Province normalization (supports CA codes and names; extendable)
const CA_PROVINCES = {
  ab: 'alberta',
  bc: 'british columbia',
  mb: 'manitoba',
  nb: 'new brunswick',
  nl: 'newfoundland and labrador',
  ns: 'nova scotia',
  nt: 'northwest territories',
  nu: 'nunavut',
  on: 'ontario',
  pe: 'prince edward island',
  qc: 'quebec',
  sk: 'saskatchewan',
  yt: 'yukon'
};

function normalizeProvince(s) {
  if (!s || typeof s !== 'string') return '';
  const raw = s.trim().toLowerCase();
  if (CA_PROVINCES[raw]) return CA_PROVINCES[raw];
  return raw;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}


class DataFaker {
  /** Return random person name parts */
  getName() {
    const firstName = fakerLib.person.firstName();
    const lastName = fakerLib.person.lastName();
    return { firstName, lastName, fullName: `${firstName} ${lastName}` };
  }

  /**
   * Return a curated static address.
   * - getAddress('QC') or getAddress('Quebec') => filter by province (case-insensitive)
   * - getAddress() => any random address
   * Returns only: street_no, street, str_name, str_type, str_dir, unit, city, postal_code, province
   */
  getAddress(province) {
    if (!Array.isArray(STATIC_ADDRESSES) || STATIC_ADDRESSES.length === 0) {
      throw new Error('No static addresses found in data/addresses.json');
    }

    let pool = STATIC_ADDRESSES;
    if (province) {
      const want = normalizeProvince(province);
      pool = STATIC_ADDRESSES.filter(a => normalizeProvince(a.province) === want);
      if (pool.length === 0) {
        throw new Error(`No addresses found for province: ${province}`);
      }
    }

    const addr = pickRandom(pool);

    // Extract only the fields we want (others may exist in your file and are ignored)
    const {
      street_no,
      street,
      str_name,
      str_type,
      str_dir,
      unit,
      city,
      postal_code,
      province: prov
    } = addr;

    return {
      street_no,
      street,
      str_name,
      str_type,
      str_dir,
      unit,
      city,
      postal_code,
      province: prov
    };
  }

  /**
   * Return a random number between min and max, rounded to `decimals` places.
   * Accepts numbers or strings like "1 million", "1.5m", "$1,250,000".
   */
  numberInRange(min, max, decimals = 2) {
    const a = min;
    const b = max;
    const lo = Math.min(a, b);
    const hi = Math.max(a, b);
    const rnd = Math.random() * (hi - lo) + lo;
    const factor = Math.pow(10, decimals);
    return Math.round(rnd * factor) / factor;
  }

  /** Return random person name parts */
  getName() {
    const firstName = fakerLib.person.firstName();
    const lastName = fakerLib.person.lastName();
    return { firstName, lastName, fullName: `${firstName} ${lastName}` };
  }

  getFirstName() {                 // ← add
    return fakerLib.person.firstName();
  }

  getLastName() {                  // ← add
    return fakerLib.person.lastName();
  }

  getEmail() {                     // ← optional, handy later
    return fakerLib.internet.email();
  }


}

module.exports = new DataFaker();
module.exports.DataFaker = DataFaker;
