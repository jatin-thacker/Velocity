class DataBag {
  constructor(obj = {}) { this._o = obj; }
  get(key) {
    const v = this._o[key];
    if (v == null) return undefined;
    const s = String(v).trim();
    return s === '' ? undefined : s;
  }
  toObject(){ return { ...this._o }; }
}
module.exports = { DataBag };
