// helpers/tasks/borrowers.js

function digits(s) { return (s ?? '').toString().replace(/\D/g, ''); }
function splitPhone(s) {
  const d = digits(s);
  return { area: d.slice(0,3), top: d.slice(3,6), bottom: d.slice(6,10) };
}
function toMMMddYYYY(iso) {
  if (!iso) return '';
  const d = new Date(`${iso}T00:00:00`);
  const m = d.toLocaleString('en-US', { month: 'short' });
  const dd = String(d.getDate()).padStart(2, '0');
  return `${m}-${dd}-${d.getFullYear()}`;
}

// Try to make the Borrowers section usable. We don't rely on any static UI helpers.
async function ensureAddButtonVisible(ui) {
  // Happy path: already visible
  try {
    const visible = await ui.isVisible?.('Borrowers.addBorrower');
    if (visible) return true;
  } catch (_) { /* fall through */ }

  // Toggle the accordion header once, then re-check
  try {
    await ui.click('Borrowers.header');
  } catch (_) { /* header might be already open; ignore */ }

  try {
    const visible = await ui.isVisible?.('Borrowers.addBorrower');
    return !!visible;
  } catch (_) {
    // Worst case: we’ll still try to click 'add' and let UI throw if absent
    return false;
  }
}

// Fill the “New Contact” modal from a DataBag + CASL boolean.
async function addBorrowerFromBag(ui, bag, casl, { faker } = {}) {
  // Ensure section open / button visible (best-effort)
  await ensureAddButtonVisible(ui);

  // Click Add Borrower; if it fails, try header then click again
  try {
    await ui.click('Borrowers.addBorrower');
  } catch (e1) {
    await ui.click('Borrowers.header');        // try to expand
    await ui.click('Borrowers.addBorrower');   // try again
  }

  // First/Last (value-or-fake)
  const first = bag.get('FirstName') || faker?.getFirstName?.();
  const last  = bag.get('LastName')  || faker?.getLastName?.();
  await ui.fill('Borrowers.modal.firstName', first || '');
  await ui.fill('Borrowers.modal.lastName',  last  || '');

  // DOB → MMM-dd-yyyy
  const dobIso = bag.get('DOB');
  if (dobIso) await ui.fill('Borrowers.modal.dob', toMMMddYYYY(dobIso));

  // Email (optional)
  const email = bag.get('Email');
  if (email) await ui.fill('Borrowers.modal.email', email);

  // CASL checkbox
  try { await ui.check('Borrowers.modal.casl', !!casl); } catch (_) {}

  // Phones (segmented)
  const hp = bag.get('HomePhone');
  if (hp) {
    const p = splitPhone(hp);
    await ui.fill('Borrowers.modal.home.area',   p.area);
    await ui.fill('Borrowers.modal.home.top',    p.top);
    await ui.fill('Borrowers.modal.home.bottom', p.bottom);
  }

  const cp = bag.get('CellPhone');
  if (cp) {
    const p = splitPhone(cp);
    await ui.fill('Borrowers.modal.cell.area',   p.area);
    await ui.fill('Borrowers.modal.cell.top',    p.top);
    await ui.fill('Borrowers.modal.cell.bottom', p.bottom);
  }

  // Contact Preference
  const pref = bag.get('ContactPref');
  if (pref) { try { await ui.selectByLabel('Borrowers.modal.contactPref', pref); } catch (_) {} }

  // Save
  await ui.click('Borrowers.modal.ok');

  return { ok: true };
}

module.exports = { addBorrowerFromBag };
