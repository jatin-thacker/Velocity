getApplicantByIdStrict = require('./src/utils/dataStore')

const applicant = getApplicantByIdStrict('AP002');
await ui.fill('Borrowers.modal.firstName', applicant.FirstName || fake.getFirstName());
