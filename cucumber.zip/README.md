# 🏗️ Velocity Automation Framework

End-to-end UI test automation framework built with **Cucumber (BDD)**, **Playwright**, and **Node.js**  
Designed to scale with **atomic steps**, **data-driven testing**, and a rich **locator audit system**.

---

## 📦 Project Structure

├── config/
│ └── env/ # JSON files for environment storage state (uat.json, sit.json, …)
├── data/
│ ├── addresses.json # Curated Canadian addresses for FakerUtil
│ └── *.xlsx # Test data catalogs (ApplicantsCatalog, EndToEnd, etc.)
├── reports/ # Traces, audit summaries, and test reports
├── src/
│ ├── core/
│ │ └── basePage.js # Base class for locator resolution + audit logging
│ ├── data/
│ │ └── domain/ # Domain mappers (applicant.js, scenario.js, …)
│ ├── tasks/ # Reusable tasks (borrowers.js, deals.js, …)
│ └── utils/ # Utilities (ui.js, fakerUtil.js, dataStore.js, locators.js, …)
├── tests/
│ ├── features/ # Gherkin feature files
│ │ └── smoke.feature
│ ├── steps/ # Step definitions (ui.steps.js, quick_deal.steps.js, …)
│ └── support/ # Hooks + audit system
│ ├── audit.js
│ └── hooks.js
└── package.json


---

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install

2. Run Tests

Headless run (default):

npm run bdd


Headed (debug-friendly, shows browser):

npm run demo


With slow motion:

cross-env HEADED=1 SLOWMO=250 cucumber-js

3. Reports

Traces are stored in reports/trace-<timestamp>.zip

Audit summaries are saved in reports/audit-summary.json

HTML report:

npm run report:mchr && npm run open:cucumber

🧩 Core Concepts
1. Atomic Steps

Steps are small, reusable building blocks.
Example (smoke.feature):

Scenario: Login and land on home
  Given Read the test data for "SC01" from "EndToEnd"
  Given Login into the Velocity Application using user "scotia-admin" from environment sheet "SIT"
  When I click "velocity.link"
  When I open Add and start a new Application
  Given I fill the initial application details
  When I fill additional borrowers

2. Locator Registry

All UI interactions are keyed by logical names (Borrowers.addBorrower, quick.firstName, …).
Locators are resolved via locators.js with multi-strategy healing:

PRIMARY: first match

HEALED / HEALER: fallback strategies

FAIL: audit entry when nothing matches

Audit is attached per step and summarized at run end.

3. Audit Logging

Every interaction produces structured events (resolve, click, fill, …)

Events are attached to steps for traceability

Run-level summary includes counters + plain table:

Element Key          | Result    | Used | Total | Selector snippet
---------------------+-----------+------+-------+----------------------------
quick.firstName      | PRIMARY   | 1    | 4     | #quick_firstname
Borrowers.addBorrowe | PRIMARY   | 1    | 2     | role=button[name=/add borrow
...

4. Data-Driven Testing

Test data lives in Excel sheets (EndToEnd, ApplicantsCatalog, …)

Utility dataStore.js parses rows and provides:

getApplicantByIdStrict(id)

getScenarioById(id)

fakerUtil.js fills gaps with realistic fake data:

const faker = require('../../src/utils/fakerUtil');
faker.getName();     // { firstName, lastName, fullName }
faker.getEmail();    // random email
faker.getAddress();  // curated Canadian address

🔨 Writing Tests

Add a new feature under tests/features/

Feature: Borrower Management
  Scenario: Add borrower to application
    Given Read the test data for "SC02" from "EndToEnd"
    When I fill additional borrowers


Reuse existing steps from tests/steps/
or compose new ones by calling into UI and tasks.

Keep steps thin:

Steps call tasks (tasks/borrowers.js, tasks/deals.js)

Tasks encapsulate workflows (open modal, fill, save, assert)

🖥️ Debugging

Run with headed mode: npm run demo

Use Playwright Inspector:

cross-env PWDEBUG=1 cucumber-js


Look at:

Per-step screenshots (attached in report)

Playwright trace (.zip) in reports/

Audit counters & table

👩‍💻 Conventions

Steps → only orchestration, never business logic

Tasks → reusable multi-step workflows

Domain Mappers → parse Excel rows → JS objects

UI Utility → single source of truth for locator resolution

Faker → fallback when data is missing

Audit → always logs resolution, selection, clicks, fills

⚡ Example Flow: Adding Borrowers
When I fill additional borrowers


Implementation:

await ui.click('Borrowers.header');
await ui.click('Borrowers.addBorrower');
await ui.within('Borrowers.modal.root').fill('Borrowers.modal.firstName', 'Jane');
await ui.within('Borrowers.modal.root').fill('Borrowers.modal.lastName',  'Doe');
await ui.within('Borrowers.modal.root').click('Borrowers.modal.ok');
await ui.assertBorrowerTabVisible('Jane Doe');

🛡️ Good Practices

Keep locators descriptive and semantic (quick.firstName, not #input1)

Always attach debug info with this.attach

Use fakerUtil for missing optional fields

Add audit logs for every UI action (already built-in)

Idempotent guards: use expectVisible instead of blindly toggling panels

📖 Useful Commands

Run single feature

npx cucumber-js tests/features/smoke.feature


Tagged run

npx cucumber-js --tags @smoke


Clean reports

npm run clean:reports

✅ Summary

This framework is:

Data-driven (Excel + Faker fallback)

Audited (locator resolution + screenshots)

Composable (atomic steps → scalable workflows)

Debuggable (trace, screenshots, audit, console logs)

Automation testers and AI agents (like Codex) can onboard quickly by:

Reading README.md (this file)

Exploring tests/features/ for examples

Using UI, tasks, and fakerUtil to extend functionality.