
// tests/steps/quick_deal.steps.js
const { Given, When } = require('@cucumber/cucumber');
const { format } = require('../../src/utils/dateUtil.js');

const { UI } = require('../../src/utils/ui');
const fake = require('../../src/utils/fakerUtil');
const { getApplicantByIdStrict } = require('../../src/utils/dataStore');
const { getPrimaryApplicantForScenario } =
  require('../../src/data/domain/applicant.js');

/* ----------------------- Quick Deal (initial) ----------------------- */

Given('I fill the initial application details', async function () {
  const attach = typeof this.attach === 'function' ? this.attach.bind(this) : async () => {};
  const ui = new UI(this.page, attach);

  const scenarioID = this?.testData?.ScenarioID || this?.data?.context?.ScenarioID;
  const dealSheet  = this?.testData?.ScenarioSheet || 'EndToEnd';

  const { bag, casl } = await getPrimaryApplicantForScenario(this, scenarioID, { dealSheet });

  const first = bag.get('FirstName') || fake.getFirstName();
  const last  = bag.get('LastName')  || fake.getLastName();

  await attach(`Initial applicant → first="${first}", last="${last}", casl=${!!casl}`);

  await ui.fill('quick.firstName', first);
  await ui.fill('quick.lastName',  last);
  try { await ui.check('quick.casl.checkbox', casl); } catch {}

  const closing = this?.__dealRow?.ClosingDate || this?.testData?.ClosingDate
    || format(new Date(), 'MMM-dd-yyyy');
  await ui.fill('quick.closingDate', closing);

  await ui.selectByLabel('quick.agent.select',
    this?.__dealRow?.Agent || this?.testData?.Agent || 'Scotia Admin');

  const mort = this?.__dealRow?.MortgageAmount || this?.testData?.MortgageAmount
    || fake.numberInRange(200000, 2000000, 0);
  await ui.fill('quick.mortgageAmount', String(mort));

  await ui.click('quick.save.button');
});

/* ----------------------- Additional Borrowers ----------------------- */

When('I fill additional borrowers', async function () {
  const attach = typeof this.attach === 'function' ? this.attach.bind(this) : async () => {};
  const ui = new UI(this.page, attach);

  // Only open the accordion if it's not already open
  const ensureBorrowersOpen = async () => {
    try {
      await ui.expectVisible('Borrowers.addBorrower', 1200); // already open
      return;
    } catch {
      // not open → click header and verify the button becomes visible
      await ui.click('Borrowers.header');
      await ui.expectVisible('Borrowers.addBorrower', 4000);
      await this.page.waitForTimeout(150);
    }
  };

  await ensureBorrowersOpen();
  await attach('Borrowers panel is open.');

  // Collect applicant IDs; skip blanks
  const s = this.testData || {};
  const ids = [
    s.SecondApplicantID, s.ThirdApplicantID, s.FourthApplicantID,
    s.FifthApplicantID,  s.SixthApplicantID,
  ]
    .map(v => (v ?? '').toString().trim())
    .filter(Boolean);

  if (ids.length === 0) {
    await attach('No additional applicants in scenario row; nothing to add.');
    return;
  }

  const resolveRow = async (id) => {
    try { return getApplicantByIdStrict(id); }
    catch (e) { await attach(`Lookup failed for "${id}": ${e?.message || e} → using Faker.`); return null; }
  };

  const openAddBorrowerModal = async () => {
    await ensureBorrowersOpen();
    // click with a tiny retry if modal doesn’t show up immediately
    for (let attempt = 1; attempt <= 3; attempt++) {
      await ui.click('Borrowers.addBorrower');
      try {
        await ui.expectVisible('Borrowers.modal.root', 3000);
        return;
      } catch {
        await attach(`Add Borrower click attempt ${attempt} → modal not visible yet, retrying...`);
        await this.page.waitForTimeout(250);
      }
    }
    await ui.expectVisible('Borrowers.modal.root', 3000);
  };

  for (const id of ids) {
    const row = await resolveRow(id);

    const first = (row?.FirstName ?? '').toString().trim() || fake.getFirstName();
    const last  = (row?.LastName  ?? '').toString().trim() || fake.getLastName();
    const email = (row?.Email     ?? '').toString().trim() || fake.getEmail();
    const dob   = (row?.DOB       ?? '').toString().trim();

    const full = [first, last].filter(Boolean).join(' ');
    await attach(`Adding borrower ${id} → "${full}" (email=${email}${dob ? `, dob=${dob}` : ''})`);

    // 1) Open modal
    await openAddBorrowerModal();

    // 2) Fill fields inside modal
    await ui.within('Borrowers.modal.root').fill('Borrowers.modal.firstName', first);
    await ui.within('Borrowers.modal.root').fill('Borrowers.modal.lastName',  last);
    if (email) await ui.within('Borrowers.modal.root').fill('Borrowers.modal.email', email);
    if (dob)   await ui.within('Borrowers.modal.root').fill('Borrowers.modal.dob',   dob);
    try { await ui.within('Borrowers.modal.root').check('Borrowers.modal.casl'); } catch {}
    try { await ui.within('Borrowers.modal.root').selectByLabel('Borrowers.modal.contactPref', 'Email'); } catch {}

    // 3) Save + wait for modal to close
    await ui.within('Borrowers.modal.root').click('Borrowers.modal.ok');
    await ui.ensureModalSaved('Borrowers.modal.root', { timeout: 12000 });
    await attach(`Borrower saved: ${full}`);

    // 4) Debounce + ensure open before next loop
    await this.page.waitForTimeout(300);
    await ensureBorrowersOpen();
  }
});
