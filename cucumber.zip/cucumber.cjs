module.exports = require('./config/cucumber.cjs');
